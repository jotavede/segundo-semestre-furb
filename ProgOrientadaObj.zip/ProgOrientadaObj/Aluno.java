public class Aluno {
    Pessoa pessoa;
    String matricula;
    String curso;
    double nota;
    boolean aprovado;
}

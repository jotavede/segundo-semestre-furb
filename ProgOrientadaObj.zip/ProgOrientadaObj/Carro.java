public class Carro {
    String modelo;
    int ano;
    String cor;
    boolean ligado;
    double quilometragem;
    Motor motor;
}

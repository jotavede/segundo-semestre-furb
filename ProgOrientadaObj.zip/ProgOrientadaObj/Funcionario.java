public class Funcionario {
    String departamento;
    String sigla;
    String cargo;
    String nome;
    double salario;
}

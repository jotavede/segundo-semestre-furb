public class Livro {
    String titulo;
    int numeroPaginas;
    int anoPublicacao;
    Pessoa autor;
}

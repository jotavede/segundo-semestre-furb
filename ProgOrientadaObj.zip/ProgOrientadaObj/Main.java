/* Aulas 1 e 2 | Instanciação simples*/

public class Main {
    public static void main(String[] args) {

        System.out.println("--- Questão 1 ---");
        Pessoa pessoa1 = new Pessoa();
        pessoa1.nome = "Ana";
        pessoa1.idade = 21;
        pessoa1.altura = 1.68;
        pessoa1.peso = 60.0;
        pessoa1.maiorDeIdade = true;

        System.out.println("Nome: " + pessoa1.nome);
        System.out.println("Idade: " + pessoa1.idade);
        System.out.println("Altura: " + pessoa1.altura + "m");
        System.out.println("Maior de idade: " + pessoa1.maiorDeIdade);

        System.out.println("\n--- Questão 2 ---");
        Pessoa pessoa2 = new Pessoa();
        pessoa2.nome = "Marcelo";
        pessoa2.idade = 25;
        pessoa2.altura = 1.75;
        pessoa2.peso = 70.0;
        pessoa2.maiorDeIdade = true;

        System.out.println("Nome: " + pessoa2.nome);
        System.out.println("Idade: " + pessoa2.idade);
        System.out.println("Altura: " + pessoa2.altura + "m");
        System.out.println("Peso: " + pessoa2.peso + "kg");
        System.out.println("Maior de idade: " + pessoa2.maiorDeIdade);

        System.out.println("\n--- Questão 3 ---");
        Pessoa pessoaA = new Pessoa();
        pessoaA.nome = "Ana";
        pessoaA.idade = 21;
        pessoaA.altura = 1.68;
        pessoaA.peso = 60.0;
        pessoaA.maiorDeIdade = true;

        Pessoa pessoaB = new Pessoa();
        pessoaB.nome = "Marcelo";
        pessoaB.idade = 25;
        pessoaB.altura = 1.75;
        pessoaB.peso = 70.0;
        pessoaB.maiorDeIdade = true;

        Pessoa pessoaC = new Pessoa();
        pessoaC.nome = "Julia";
        pessoaC.idade = 17;
        pessoaC.altura = 1.60;
        pessoaC.peso = 55.0;
        pessoaC.maiorDeIdade = false;

        System.out.println("Pessoa A: " + pessoaA.nome + ", " + pessoaA.idade + " anos, " + pessoaA.altura + "m");
        System.out.println("Pessoa B: " + pessoaB.nome + ", " + pessoaB.idade + " anos, " + pessoaB.altura + "m");
        System.out.println("Pessoa C: " + pessoaC.nome + ", " + pessoaC.idade + " anos, " + pessoaC.altura + "m");

        double imcA = pessoaA.peso / (pessoaA.altura * pessoaA.altura);
        double imcB = pessoaB.peso / (pessoaB.altura * pessoaB.altura);
        double imcC = pessoaC.peso / (pessoaC.altura * pessoaC.altura);

        System.out.printf("IMC de %s: %.2f%n", pessoaA.nome, imcA);
        System.out.printf("IMC de %s: %.2f%n", pessoaB.nome, imcB);
        System.out.printf("IMC de %s: %.2f%n", pessoaC.nome, imcC);

        System.out.println("\n--- Questão 4 ---");
        Livro livro1 = new Livro();
        livro1.titulo = "Clean Code";
        livro1.numeroPaginas = 464;
        livro1.anoPublicacao = 2008;
        Pessoa autorRobert = new Pessoa();
        autorRobert.nome = "Robert C. Martin";
        livro1.autor = autorRobert;

        System.out.println("Titulo: " + livro1.titulo);
        System.out.println("Paginas: " + livro1.numeroPaginas);
        System.out.println("Ano: " + livro1.anoPublicacao);
        System.out.println("Autor: " + livro1.autor.nome);

        System.out.println("\n--- Questão 5 ---");
        Produto produto1 = new Produto();
        produto1.nome = "Teclado Mecanico";
        produto1.preco = 150.00;
        produto1.quantidade = 10;
        produto1.tipo = "Perifericos";

        Produto produto2 = new Produto();
        produto2.nome = "Monitor 24 Polegadas";
        produto2.preco = 399.90;
        produto2.quantidade = 5;
        produto2.tipo = "Eletronicos";

        System.out.println("Produto 1: " + produto1.nome + " | Preco: R$" + produto1.preco + " | Quantidade: "
                + produto1.quantidade + " | Tipo: " + produto1.tipo);
        System.out.println("Produto 2: " + produto2.nome + " | Preco: R$" + produto2.preco + " | Quantidade: "
                + produto2.quantidade + " | Tipo: " + produto2.tipo);

        System.out.println("\n--- Questão 6 ---");
        Carro carro1 = new Carro();
        carro1.modelo = "Civic";
        carro1.ano = 2024;
        carro1.ligado = false;
        carro1.quilometragem = 15000.0;

        Carro carro2 = new Carro();
        carro2.modelo = "Corolla";
        carro2.ano = 2017;
        carro2.ligado = true;
        carro2.quilometragem = 121683.0;

        System.out.println("Carro 1: " + carro1.modelo + " | Ano: " + carro1.ano + " | Ligado: " + carro1.ligado
                + " | Km: " + carro1.quilometragem);
        System.out.println("Carro 2: " + carro2.modelo + " | Ano: " + carro2.ano + " | Ligado: " + carro2.ligado
                + " | Km: " + carro2.quilometragem);

        /* Aula 3 | Objetos relacionados */

        System.out.println("\n--- Questão 7 ---");
        Pessoa carlos = new Pessoa();
        carlos.nome = "Carlos";
        carlos.idade = 19;
        carlos.altura = 1.83;
        carlos.peso = 79.7;
        carlos.maiorDeIdade = true;

        Aluno alunoCarlos = new Aluno();
        alunoCarlos.pessoa = carlos;
        alunoCarlos.matricula = "20260002";
        alunoCarlos.curso = "Ciência de Dados";
        alunoCarlos.nota = 8.5;
        alunoCarlos.aprovado = true;

        System.out.println("Aluno: " + alunoCarlos.pessoa.nome);
        System.out.println("Idade: " + alunoCarlos.pessoa.idade);
        System.out.println("Matricula: " + alunoCarlos.matricula);
        System.out.println("Curso: " + alunoCarlos.curso);
        System.out.println("Nota: " + alunoCarlos.nota);
        System.out.println("Aprovado: " + alunoCarlos.aprovado);

        System.out.println("\n--- Questão 8 ---");
        Pessoa maria = new Pessoa();
        maria.nome = "Maria";
        maria.idade = 49;
        maria.altura = 1.65;
        maria.peso = 68.6;
        maria.maiorDeIdade = true;

        Livro livroMaria = new Livro();
        livroMaria.titulo = "Tdah! A Arte da Guerra";
        livroMaria.numeroPaginas = 256;
        livroMaria.anoPublicacao = 2022;
        livroMaria.autor = maria;

        System.out.println("Livro: " + livroMaria.titulo);
        System.out.println("Paginas: " + livroMaria.numeroPaginas);
        System.out.println("Ano: " + livroMaria.anoPublicacao);
        System.out.println("Autor: " + livroMaria.autor.nome);

        System.out.println("\n--- Questão 9 ---");
        Pessoa marcos = new Pessoa();
        marcos.nome = "Marcos";
        marcos.idade = 30;
        marcos.altura = 1.80;
        marcos.peso = 85.0;

        Pessoa juliana = new Pessoa();
        juliana.nome = "Juliana";
        juliana.idade = 28;
        juliana.altura = 1.70;
        juliana.peso = 65.0;

        Livro livroMarcos = new Livro();
        livroMarcos.titulo = "E-commerce: Estratégias e Negócios";
        livroMarcos.numeroPaginas = 320;
        livroMarcos.anoPublicacao = 2021;
        livroMarcos.autor = marcos;

        Livro livroJuliana = new Livro();
        livroJuliana.titulo = "Marketing Digital: Conceitos e Práticas";
        livroJuliana.numeroPaginas = 280;
        livroJuliana.anoPublicacao = 2020;
        livroJuliana.autor = juliana;

        System.out.println("Livro 1: " + livroMarcos.titulo + " | Autor: " + livroMarcos.autor.nome);
        System.out.println("Livro 2: " + livroJuliana.titulo + " | Autor: " + livroJuliana.autor.nome);

        System.out.println("\n--- Questão 10 ---");
        Produto produtoA = new Produto();
        produtoA.nome = "Notebook";
        produtoA.preco = 4500.00;
        produtoA.quantidade = 8;
        produtoA.disponivel = true;

        Pessoa joao = new Pessoa();
        joao.nome = "João";
        joao.idade = 39;
        joao.altura = 1.95;
        joao.peso = 90.0;
        joao.maiorDeIdade = true;

        produtoA.comprador = joao;
        System.out.println("Produto: " + produtoA.nome);
        System.out.println("Comprador: " + produtoA.comprador.nome);
        System.out.println("Preço: R$" + produtoA.preco);
        System.out.println("Quantidade: 1");

        System.out.println("\n--- Questão 11 ---");
        Pessoa eduardo = new Pessoa();
        eduardo.nome = "Eduardo";
        eduardo.idade = 18;
        eduardo.altura = 1.75;
        eduardo.peso = 73.0;
        eduardo.maiorDeIdade = true;

        Pessoa fernanda = new Pessoa();
        fernanda.nome = "Fernanda";
        fernanda.idade = 22;
        fernanda.altura = 1.68;
        fernanda.peso = 60.0;
        fernanda.maiorDeIdade = true;

        Produto produtoB = new Produto();
        produtoB.nome = "iPhone 14";
        produtoB.preco = 3650.00;
        produtoB.quantidade = 1;
        produtoB.disponivel = true;
        produtoB.comprador = eduardo;

        Produto produtoC = new Produto();
        produtoC.nome = "Carregador Original Apple";
        produtoC.preco = 199.00;
        produtoC.quantidade = 1;
        produtoC.disponivel = true;
        produtoC.comprador = eduardo;

        Produto produtoD = new Produto();
        produtoD.nome = "Fone de Ouvido Bluetooth";
        produtoD.preco = 299.00;
        produtoD.quantidade = 1;
        produtoD.disponivel = true;
        produtoD.comprador = fernanda;

        System.out.println("Produto: " + produtoC.nome);
        System.out.println("Comprador: " + produtoC.comprador.nome);
        System.out.println("Preço: R$" + produtoC.preco);
        System.out.println("Produto: " + produtoD.nome);
        System.out.println("Comprador: " + produtoD.comprador.nome);
        System.out.println("Preço: R$" + produtoD.preco);

        System.out.println("\n--- Questão 12 ---");
        Pessoa roberto = new Pessoa();
        roberto.nome = "Roberto";
        roberto.idade = 45;
        roberto.altura = 1.78;
        roberto.peso = 85.0;
        roberto.maiorDeIdade = true;

        Carro carroRoberto = new Carro();
        carroRoberto.modelo = "Porsche Cayenne";
        carroRoberto.ano = 2022;
        carroRoberto.cor = "Preto";
        carroRoberto.ligado = false;
        carroRoberto.quilometragem = 17861.3;

        System.out.println("Carro: " + carroRoberto.modelo);
        System.out.println("Ano: " + carroRoberto.ano);
        System.out.println("Cor: " + carroRoberto.cor);
        System.out.println("Quilometragem: " + carroRoberto.quilometragem);

        /* Parte 3 – Trabalhando com subobjetos */

        System.out.println("\n--- Questão 13 ---");

        Fabricante fabricante1 = new Fabricante();
        fabricante1.nome = "Dell";
        fabricante1.pais = "Estados Unidos";

        Produto notebook = new Produto();
        notebook.nome = "Notebook Dell Inspiron";
        notebook.preco = 3500.00;
        notebook.quantidade = 1;
        notebook.fabricante = fabricante1;

        System.out.println("Produto: " + notebook.nome);
        System.out.println("Fabricante: " + notebook.fabricante.nome);
        System.out.println("País do fabricante: " + notebook.fabricante.pais);
        System.out.println("Preço: R$" + notebook.preco);

        System.out.println("\n--- Questão 14 ---");

        Fabricante fabricante2 = new Fabricante();
        fabricante2.nome = "Samsung";
        fabricante2.pais = "Coreia do Sul";

        Fabricante fabricante3 = new Fabricante();
        fabricante3.nome = "New Balance";
        fabricante3.pais = "Estados Unidos";

        Produto celular = new Produto();
        celular.nome = "Celular Samsung Galaxy S21";
        celular.preco = 2500.00;
        celular.fabricante = fabricante2;
        celular.fabricante.pais = "Coreia do Sul";

        Produto televisao = new Produto();
        televisao.nome = "Televisão 8K Samsung QLED";
        televisao.preco = 8000.00;
        televisao.fabricante = fabricante2;
        televisao.fabricante.pais = "Coreia do Sul";

        Produto jaqueta = new Produto();
        jaqueta.nome = "Jaqueta Columbia";
        jaqueta.preco = 400.00;
        jaqueta.fabricante = new Fabricante();
        jaqueta.fabricante.nome = "Columbia Sportswear";
        jaqueta.fabricante.pais = "Estados Unidos";

        System.out.println("Produto: " + celular.nome);
        System.out.println("Fabricante: " + celular.fabricante.nome);
        System.out.println("País do fabricante: " + celular.fabricante.pais);
        System.out.println("Preço: R$" + celular.preco);

        System.out.println("Produto: " + televisao.nome);
        System.out.println("Fabricante: " + televisao.fabricante.nome);
        System.out.println("País do fabricante: " + televisao.fabricante.pais);
        System.out.println("Preço: R$" + televisao.preco);

        System.out.println("Produto: " + jaqueta.nome);
        System.out.println("Fabricante: " + jaqueta.fabricante.nome);
        System.out.println("País do fabricante: " + jaqueta.fabricante.pais);
        System.out.println("Preço: R$" + jaqueta.preco);

        System.out.println("\n--- Questão 15 ---");
        Pessoa lucas = new Pessoa();
        lucas.nome = "Lucas";
        lucas.idade = 30;
        lucas.altura = 1.80;
        lucas.peso = 75.0;

        Fabricante mizuno = new Fabricante();
        mizuno.nome = "Mizuno";
        mizuno.pais = "Japão";

        Produto tenisM = new Produto();
        tenisM.nome = "Tênis Mizuno Wave";
        tenisM.preco = 350.00;
        tenisM.fabricante = mizuno;
        tenisM.comprador = lucas;

        System.out.println("\n--- Questão 16 ---");
        Motor motor1 = new Motor();
        motor1.potencia = 150.0;
        motor1.cilindrada = 1.3;
        motor1.tipoCombustivel = "Gasolina";

        Carro audiA3 = new Carro();
        audiA3.modelo = "Audi A3";
        audiA3.ano = 2020;
        audiA3.cor = "Prata";
        audiA3.ligado = false;
        audiA3.quilometragem = 28658.4;
        audiA3.motor = motor1;

        System.out.println("\n--- Questão 17 ---");
        Motor motorA = new Motor();
        motorA.potencia = 200.0;
        motorA.cilindrada = 2.0;
        motorA.tipoCombustivel = "Gasolina";

        Motor motorB = new Motor();
        motorB.potencia = 350.0;
        motorB.cilindrada = 1.6;
        motorB.tipoCombustivel = "Diesel";

        Carro carroA = new Carro();
        carroA.modelo = "BMW Série 3";
        carroA.ano = 2021;
        carroA.cor = "Preto";
        carroA.ligado = true;
        carroA.quilometragem = 92835.0;
        carroA.motor = motorA;

        Carro carroB = new Carro();
        carroB.modelo = "Ford Mustang";
        carroB.ano = 2022;
        carroB.cor = "Vermelho";
        carroB.ligado = false;
        carroB.quilometragem = 12734.8;
        carroB.motor = motorB;

        System.out.println("Carro A: " + carroA.modelo + " | Ano: " + carroA.ano + " | Cor: " + carroA.cor
                + " | Ligado: " + carroA.ligado + " | Km: " + carroA.quilometragem);
        System.out.println("Motor A: " + carroA.motor.potencia + "cv | Cilindrada: " + carroA.motor.cilindrada +
                "L | Combustível: " + carroA.motor.tipoCombustivel);
        System.out.println("Carro B: " + carroB.modelo + " | Ano: " + carroB.ano + " | Cor: " + carroB.cor
                + " | Ligado: " + carroB.ligado + " | Km: " + carroB.quilometragem);
        System.out.println("Motor B: " + carroB.motor.potencia + "cv | Cilindrada: " + carroB.motor.cilindrada +
                "L | Combustível: " + carroB.motor.tipoCombustivel);

        System.out.println("\n--- Questão 18 ---");
        Pessoa joaoV = new Pessoa();
        joaoV.nome = "João Victor";
        joaoV.idade = 22;
        joaoV.altura = 1.81;
        joaoV.peso = 79.3;

        Carro carroJoao = new Carro();
        carroJoao.modelo = "Honda Accord";
        carroJoao.ano = 2005;
        carroJoao.cor = "Branco";
        carroJoao.ligado = false;
        carroJoao.quilometragem = 178320.6;

        Motor motorJoao = new Motor();
        motorJoao.potencia = 180.0;
        motorJoao.cilindrada = 2.4;
        motorJoao.tipoCombustivel = "Gasolina";

        System.out.println("Proprietário: " + joaoV.nome);
        System.out.println("Carro: " + carroJoao.modelo + " | Ano: " + carroJoao.ano + " | Cor: " + carroJoao.cor
                + " | Ligado: " + carroJoao.ligado + " | Km: " + carroJoao.quilometragem);
        System.out.println("Motor: " + motorJoao.potencia + "cv | Cilindrada: " + motorJoao.cilindrada + "L | Combustível: " + 
        motorJoao.tipoCombustivel);

        System.out.println("\n--- Questão 19 ---");
        Funcionario funcionario1 = new Funcionario();
        funcionario1.nome = "João";
        funcionario1.departamento = "Tecnologia";
        funcionario1.sigla = "TI";
        funcionario1.cargo = "Desenvolvedor";
        funcionario1.salario = 5000.00;

        System.out.println("Funcionário: " + funcionario1.nome);
        System.out.println("Departamento: " + funcionario1.departamento + " | Sigla: " + funcionario1.sigla);
        System.out.println("Cargo: " + funcionario1.cargo + " | Salário: R$" + funcionario1.salario);

        System.out.println("\n--- Questão 20 ---");
        Funcionario funcionario2 = new Funcionario();
        funcionario2.nome = "Maria";
        funcionario2.departamento = "Financeiro";
        funcionario2.sigla = "FIN";
        funcionario2.cargo = "Contadora";
        funcionario2.salario = 4500.00;

        Funcionario funcionario3 = new Funcionario();
        funcionario3.nome = "José";
        funcionario3.departamento = "Financeiro";
        funcionario3.sigla = "FIN";
        funcionario3.cargo = "Analista";
        funcionario3.salario = 4000.00;

        Funcionario funcionario4 = new Funcionario();
        funcionario4.nome = "Ana";
        funcionario4.departamento = "Financeiro";
        funcionario4.sigla = "FIN";
        funcionario4.cargo = "Assistente";
        funcionario4.salario = 2500.00;

        System.out.println("Funcionário: " + funcionario2.nome);
        System.out.println("Departamento: " + funcionario2.departamento + " | Sigla: " + funcionario2.sigla);
        System.out.println("Cargo: " + funcionario2.cargo + " | Salário: R$" + funcionario2.salario);
        System.out.println("Funcionário: " + funcionario3.nome);
        System.out.println("Departamento: " + funcionario3.departamento + " | Sigla: " + funcionario3.sigla);
        System.out.println("Cargo: " + funcionario3.cargo + " | Salário: R$" + funcionario3.salario);
        System.out.println("Funcionário: " + funcionario4.nome);
        System.out.println("Departamento: " + funcionario4.departamento + " | Sigla: " + funcionario4.sigla);
        System.out.println("Cargo: " + funcionario4.cargo + " | Salário: R$" + funcionario4.salario);

/* Parte 4 - Mais de um nível de objetos */
        System.out.println("\n--- Questão 21 ---");
        Pessoa alfredo = new Pessoa();
        alfredo.nome = "Alfredo";
        alfredo.idade = 35;
        alfredo.altura = 1.75;
        alfredo.peso = 80.0;

        Fabricante fabricanteAlfredo = new Fabricante();
        fabricanteAlfredo.nome = "Havaianas";
        fabricanteAlfredo.pais = "Brasil";

        Produto produtoAlfredo = new Produto();
        produtoAlfredo.nome = "Chinelo Havaianas";
        produtoAlfredo.preco = 50.0;
        produtoAlfredo.fabricante = fabricanteAlfredo;

        
    }
}
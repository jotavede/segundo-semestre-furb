public class Motor {
    double potencia;
    double cilindrada;
    String tipoCombustivel;
}

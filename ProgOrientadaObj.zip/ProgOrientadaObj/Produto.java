public class Produto {
    String nome;
    double preco;
    int quantidade;
    String tipo;
    boolean disponivel;
    Pessoa comprador;
    Fabricante fabricante;
}
